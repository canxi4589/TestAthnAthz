﻿namespace TestIdentityReal.Service
{
    public class EmailSender
    {
    }
}
