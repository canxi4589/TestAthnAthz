﻿namespace TestIdentityReal.Service
{
    public class BlobStorageService
    {
    }
}
