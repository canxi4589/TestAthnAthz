﻿namespace TestIdentityReal.Service
{
    public class FileService
    {
    }
}
