﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using TestIdentityReal.Entity;

namespace TestIdentityReal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;
        private readonly UserManager<AppUser> _userManager;
        private readonly TokenHelper _tokenHelper;

        public AuthenticationController(ILogger<WeatherForecastController> logger, UserManager<AppUser> userManager, TokenHelper tokenHelper)
        {
            _logger = logger;
            _userManager = userManager;
            _tokenHelper = tokenHelper;
        }

    }
}
