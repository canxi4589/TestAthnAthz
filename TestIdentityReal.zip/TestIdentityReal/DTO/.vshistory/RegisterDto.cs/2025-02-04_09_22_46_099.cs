﻿namespace TestIdentityReal.DTO
{
    public class RegisterDto
    {
    }
}
