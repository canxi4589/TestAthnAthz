﻿namespace TestIdentityReal.DTO
{
    public class FileDTO
    {
    }
}
