﻿namespace TestIdentityReal.DTO
{
    public class GoogleLoginDto
    {
    }
}
