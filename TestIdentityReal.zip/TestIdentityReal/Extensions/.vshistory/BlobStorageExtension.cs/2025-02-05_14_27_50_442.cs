﻿namespace TestIdentityReal.Extensions
{
    public class BlobStorageExtension
    {
    }
}
