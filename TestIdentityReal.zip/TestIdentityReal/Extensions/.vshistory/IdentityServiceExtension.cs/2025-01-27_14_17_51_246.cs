﻿namespace TestIdentityReal.Extensions
{
    public class IdentityServiceExtension
    {
    }
}
