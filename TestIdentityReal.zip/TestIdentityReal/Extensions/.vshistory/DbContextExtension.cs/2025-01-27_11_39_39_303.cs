﻿namespace TestIdentityReal.Extensions
{
    public class DbContextExtension
    {
    }
}
