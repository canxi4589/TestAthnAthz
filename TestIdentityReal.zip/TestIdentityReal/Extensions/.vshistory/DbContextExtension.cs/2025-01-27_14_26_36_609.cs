﻿using Microsoft.EntityFrameworkCore;
using TestIdentityReal.Data;

namespace TestIdentityReal.Extensions
{
    public static class DbContextExtension
    {
        public static IServiceCollection AddDatabaseConfig(
            this IServiceCollection services,
            IConfiguration config
        )
        {
            services.AddDbContext<DbContext1>(opt =>
                opt.UseSqlServer(config.GetConnectionString("DefaultConnection"))
            );

            return services;
        }

        public static async Task<WebApplication> AddAutoMigrateDatabase(this WebApplication app)
        {
            using var scope = app.Services.CreateScope();
            var serviceProvider = scope.ServiceProvider;
            var loggerFactory = serviceProvider.GetRequiredService<ILoggerFactory>();
            try
            {
                var context = serviceProvider.GetRequiredService<DbContext1>();
                await context.Database.MigrateAsync();
            }
            catch (Exception ex)
            {
                var logger = loggerFactory.CreateLogger<Program>();
                logger.LogError(ex, "An error occur during migration");
            }

            return app;
        }
    }
}
