﻿namespace TestIdentityReal.Extensions
{
    public class AutoMigrateAndSeed
    {
    }
}
