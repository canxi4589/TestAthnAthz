﻿namespace TestIdentityReal.Helper
{
    public class AppResponse
    {
    }
}
