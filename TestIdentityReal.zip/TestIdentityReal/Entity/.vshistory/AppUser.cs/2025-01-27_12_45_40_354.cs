﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace TestIdentityReal.Entity
{
    public class AppUser : IdentityUser
    {
        [MaxLength(50)]
        public string FirstName { set; get; } = string.Empty;
        [MaxLength(50)]
        public string LastName { set; get; } = string.Empty;

        [DataType(DataType.Date)]
        public DateTime? Birthday { set; get; }

        [DataType(DataType.Text)]
        public string Avatar { get; set; } = string.Empty;
        public decimal BalanceWallet { get; set; } = 0;

    }
}
