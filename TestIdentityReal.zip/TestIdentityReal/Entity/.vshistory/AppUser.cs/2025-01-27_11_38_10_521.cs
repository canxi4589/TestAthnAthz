﻿namespace TestIdentityReal.Entity
{
    public class AppUser
    {
    }
}
