﻿using Microsoft.AspNetCore.Identity;

namespace TestIdentityReal.Entity
{
    public class AppUser : IdentityUser
    {

    }
}
